(() => {
  const DEFAULT_SERVER_URL = "https://port-0-arguchessthird-mqufv2f3f11bcb06.sel3.cloudtype.app";
  const LEGACY_DEFAULT_SERVER_URLS = new Set(["http://localhost:8787", "http://localhost:3000"]);
  const STORAGE_SERVER_URL = "serverUrl";
  const STORAGE_LAST_ROOM_CODE = "lastRoomCode";
  const STORAGE_LAST_ROOM_AT = "lastRoomAt";
  const LAST_ROOM_TTL_MS = 6 * 60 * 60 * 1000;
  const CLOSED_ROOM_SUPPRESS_MS = 10 * 60 * 1000;
  const SERVER_STATUS_CHECK_MS = 15 * 1000;
  const SERVER_STATUS_TIMEOUT_MS = 2500;
  const ROOM_HEARTBEAT_MS = 5 * 1000;
  const ROOM_CODE_RE = /\b\d{4}\b/;
  const INSTALL_URL = "https://uki0903.github.io/Arguchess-thirdparty-web/#install";
  const EXTENSION_VERSION = globalThis.chrome?.runtime?.getManifest?.().version || "0.0.0";

  const state = {
    view: "home",
    rooms: [],
    loadingRooms: false,
    error: "",
    busy: false,
    eventSource: null,
    createArmedUntil: 0,
    publishedCode: "",
    publishedHeartbeatAt: 0,
    publishedHeartbeatFailures: 0,
    removingCode: "",
    lastRoomCode: "",
    lastRoomAt: 0,
    closedRoomCode: "",
    closedRoomUntil: 0,
    rejoinAttemptCode: "",
    rejoinAttemptUntil: 0,
    serverStatus: "checking",
    serverStatusText: "서버 확인 중",
    installUrl: INSTALL_URL
  };

  const chatState = {
    root: null,
    roomCode: "",
    peerId: makePeerId(),
    signalSource: null,
    peers: new Map(),
    messages: [],
    seenMessages: new Set(),
    missingRoomChecks: 0,
    panelOpen: false,
    unread: 0,
    status: ""
  };

  let renderQueued = false;
  let serverUrlPromise = null;
  let suppressMutationRender = false;
  let observedOverlay = null;
  let observedHand = null;
  let serverStatusChecking = false;
  let heartbeatInFlight = false;
  let cachedServerBaseUrl = DEFAULT_SERVER_URL;

  function makePeerId() {
    if (globalThis.crypto?.randomUUID) return crypto.randomUUID();
    return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
  }

  function getStorageValue(key) {
    return new Promise((resolve) => {
      if (!globalThis.chrome?.storage?.sync) {
        resolve(null);
        return;
      }
      chrome.storage.sync.get({ [key]: "" }, (items) => {
        resolve(items?.[key] || null);
      });
    });
  }

  function getLocalStorageValues(defaults) {
    return new Promise((resolve) => {
      if (!globalThis.chrome?.storage?.local) {
        resolve(defaults);
        return;
      }
      chrome.storage.local.get(defaults, (items) => {
        resolve(items || defaults);
      });
    });
  }

  function setLocalStorageValues(values) {
    return new Promise((resolve) => {
      if (!globalThis.chrome?.storage?.local) {
        resolve();
        return;
      }
      chrome.storage.local.set(values, resolve);
    });
  }

  async function serverBaseUrl() {
    if (!serverUrlPromise) {
      serverUrlPromise = getStorageValue(STORAGE_SERVER_URL).then((value) => {
        return normalizeServerUrl(value);
      });
    }
    cachedServerBaseUrl = await serverUrlPromise;
    return cachedServerBaseUrl;
  }

  function normalizeServerUrl(value) {
    const normalized = String(value || "").trim().replace(/\/+$/, "");
    if (!normalized || LEGACY_DEFAULT_SERVER_URLS.has(normalized)) return DEFAULT_SERVER_URL;
    return normalized;
  }

  async function loadLastRoomCode() {
    const items = await getLocalStorageValues({
      [STORAGE_LAST_ROOM_CODE]: "",
      [STORAGE_LAST_ROOM_AT]: 0
    });
    const code = String(items[STORAGE_LAST_ROOM_CODE] || "").trim();
    const savedAt = Number(items[STORAGE_LAST_ROOM_AT]) || 0;
    if (!ROOM_CODE_RE.test(code) || Date.now() - savedAt > LAST_ROOM_TTL_MS) {
      state.lastRoomCode = "";
      state.lastRoomAt = 0;
      return;
    }
    state.lastRoomCode = code;
    state.lastRoomAt = savedAt;
    queueRender();
  }

  async function rememberLastRoomCode(code) {
    if (!ROOM_CODE_RE.test(code) || state.lastRoomCode === code || isClosedRoomCode(code)) return;
    const savedAt = Date.now();
    state.lastRoomCode = code;
    state.lastRoomAt = savedAt;
    await setLocalStorageValues({
      [STORAGE_LAST_ROOM_CODE]: code,
      [STORAGE_LAST_ROOM_AT]: savedAt
    });
    queueRender();
  }

  function isClosedRoomCode(code) {
    return ROOM_CODE_RE.test(code) && state.closedRoomCode === code && Date.now() < state.closedRoomUntil;
  }

  async function markRoomClosed(code) {
    if (!ROOM_CODE_RE.test(code)) return;
    state.closedRoomCode = code;
    state.closedRoomUntil = Date.now() + CLOSED_ROOM_SUPPRESS_MS;
    if (state.lastRoomCode === code) {
      await forgetLastRoomCode();
    } else {
      queueRender();
    }
  }

  async function forgetLastRoomCode() {
    state.lastRoomCode = "";
    state.lastRoomAt = 0;
    removeStartRejoinPrompt();
    await setLocalStorageValues({
      [STORAGE_LAST_ROOM_CODE]: "",
      [STORAGE_LAST_ROOM_AT]: 0
    });
    queueRender();
  }

  function removeStartRejoinPrompt() {
    document.querySelectorAll(".acm-start-rejoin").forEach((element) => element.remove());
  }

  async function apiFetch(path, options = {}) {
    const baseUrl = await serverBaseUrl();
    const response = await fetch(`${baseUrl}${path}`, {
      ...options,
      headers: {
        "content-type": "application/json",
        ...(options.headers || {})
      }
    });
    if (!response.ok) {
      const message = await response.text().catch(() => "");
      throw new Error(message || `HTTP ${response.status}`);
    }
    if (response.status === 204) return null;
    return response.json();
  }

  async function checkServerStatus() {
    if (serverStatusChecking) return;
    serverStatusChecking = true;
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), SERVER_STATUS_TIMEOUT_MS);
    try {
      const baseUrl = await serverBaseUrl();
      const response = await fetch(`${baseUrl}/health`, {
        cache: "no-store",
        signal: controller.signal
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json().catch(() => ({}));
      const latestVersion = String(data?.extension?.latestVersion || "").trim();
      state.installUrl = String(data?.extension?.installUrl || INSTALL_URL).trim() || INSTALL_URL;
      if (latestVersion && latestVersion !== EXTENSION_VERSION) {
        setServerStatus("version-mismatch", `버전 안 맞음 · v${latestVersion} 필요`);
      } else {
        setServerStatus("online", Number.isFinite(data?.rooms) ? `서드파티 서버 ON · ${data.rooms}개` : "서드파티 서버 ON");
      }
    } catch {
      setServerStatus("offline", "서드파티 서버 OFF");
    } finally {
      window.clearTimeout(timeout);
      serverStatusChecking = false;
    }
  }

  function setServerStatus(status, text) {
    if (state.serverStatus === status && state.serverStatusText === text) return;
    state.serverStatus = status;
    state.serverStatusText = text;
    queueRender();
  }

  function waitFor(getValue, timeoutMs = 7000) {
    const startedAt = Date.now();
    return new Promise((resolve, reject) => {
      const tick = () => {
        const value = getValue();
        if (value) {
          resolve(value);
          return;
        }
        if (Date.now() - startedAt > timeoutMs) {
          reject(new Error("Timed out waiting for Augment Chess UI."));
          return;
        }
        window.setTimeout(tick, 80);
      };
      tick();
    });
  }

  function isVisible(element) {
    if (!element || element.hidden) return false;
    if (element.closest("[hidden]")) return false;
    return true;
  }

  function queueRender() {
    if (renderQueued) return;
    renderQueued = true;
    window.setTimeout(() => {
      renderQueued = false;
      render();
    }, 0);
  }

  function modeHand() {
    return document.querySelector("#modeOverlayHand");
  }

  function onlineModeCard() {
    return document.querySelector('[data-card-id="mode-online"]');
  }

  function hideSiteModeCards(hand) {
    [...hand.children].forEach((child) => {
      if (!child.classList.contains("acm-panel")) {
        child.classList.add("acm-hidden-site-card");
      }
    });
  }

  function showSiteModeCards(hand) {
    [...hand.children].forEach((child) => {
      child.classList.remove("acm-hidden-site-card");
    });
  }

  function injectMatchCard(hand) {
    if (hand.querySelector('[data-card-id="mode-matchmaking"]')) return;
    const button = document.createElement("button");
    button.type = "button";
    button.className = "card mode-card draft-choice acm-match-card";
    button.dataset.cardId = "mode-matchmaking";
    button.style.setProperty("--i", "3");
    button.style.setProperty("--tilt", "2deg");
    button.setAttribute("aria-disabled", "false");
    button.innerHTML = `
      <div class="card-title">공개방</div>
      <div class="card-art">${publicRoomIconHtml()}</div>
      <p class="card-text">공개 방을 만들거나 현재 열린 방에 바로 입장합니다.</p>
      <div class="card-footer">
        <span class="phase">ONLINE</span>
        <span class="stars"></span>
      </div>
      <div class="acm-server-status" data-acm-server-status data-acm-status="${state.serverStatus}">
        ${escapeHtml(state.serverStatusText)}
      </div>
    `;
    button.addEventListener("click", (event) => {
      if (event.target.closest("[data-acm-server-status]") && state.serverStatus === "version-mismatch") {
        window.open(state.installUrl || INSTALL_URL, "_blank", "noopener");
        return;
      }
      state.view = "menu";
      state.error = "";
      queueRender();
    });
    hand.append(button);
  }

  function renderStartRejoin(hand) {
    let rejoin = hand.querySelector(".acm-start-rejoin");
    if (!state.lastRoomCode) {
      rejoin?.remove();
      return;
    }

    if (!rejoin) {
      rejoin = document.createElement("section");
      rejoin.className = "acm-start-rejoin";
      rejoin.innerHTML = `
        <p>방금 나간 방 <strong data-acm-last-room-code></strong>에 다시 입장할 수 있습니다. 다시 입장하시겠습니까?</p>
        <div class="acm-rejoin-actions">
          <button type="button" class="acm-mini-button acm-mini-button-primary" data-acm-action="start-rejoin" data-acm-busy>다시 입장</button>
          <button type="button" class="acm-mini-button" data-acm-action="start-forget-last">숨기기</button>
        </div>
      `;
      rejoin.addEventListener("click", (event) => {
        const action = event.target.closest("[data-acm-action]")?.dataset.acmAction;
        if (action === "start-rejoin" && state.lastRoomCode) {
          void joinRoom(state.lastRoomCode, {
            forgetLastOnFailure: true,
            returnHomeOnFailure: true
          });
        } else if (action === "start-forget-last") {
          void forgetLastRoomCode();
        }
      });
      hand.prepend(rejoin);
    }

    const codeSlot = rejoin.querySelector("[data-acm-last-room-code]");
    if (codeSlot) codeSlot.textContent = state.lastRoomCode;
    rejoin.querySelectorAll("[data-acm-busy]").forEach((button) => {
      button.disabled = state.busy;
    });
  }

  function publicRoomIconHtml() {
    return `
      <svg class="acm-online-icon" viewBox="0 0 160 96" role="img" aria-label="온라인 공개방">
        <rect class="acm-online-icon-bg" x="11" y="10" width="138" height="76" rx="10"></rect>
        <circle class="acm-online-icon-globe" cx="80" cy="48" r="28"></circle>
        <path class="acm-online-icon-line" d="M52 48h56"></path>
        <path class="acm-online-icon-line" d="M80 20c-9 8-14 18-14 28s5 20 14 28"></path>
        <path class="acm-online-icon-line" d="M80 20c9 8 14 18 14 28s-5 20-14 28"></path>
        <path class="acm-online-icon-line" d="M58 33c7 4 14 6 22 6s15-2 22-6"></path>
        <path class="acm-online-icon-line" d="M58 63c7-4 14-6 22-6s15 2 22 6"></path>
        <circle class="acm-online-icon-node acm-online-icon-node-a" cx="37" cy="30" r="6"></circle>
        <circle class="acm-online-icon-node acm-online-icon-node-b" cx="123" cy="66" r="6"></circle>
        <path class="acm-online-icon-link" d="M43 32l17 8"></path>
        <path class="acm-online-icon-link" d="M100 58l17 7"></path>
      </svg>
    `;
  }

  function render() {
    suppressMutationRender = true;
    try {
      const hand = modeHand();
      if (!hand) return;
      const choosing = !document.querySelector("#modeOverlay")?.hidden && onlineModeCard();
      if (!choosing && state.view !== "home") return;

      if (state.view === "home") {
        hand.querySelector(".acm-panel")?.remove();
        showSiteModeCards(hand);
        injectMatchCard(hand);
        renderServerStatus(hand);
        renderStartRejoin(hand);
        return;
      }

      const currentPanel = hand.querySelector(".acm-panel");
      if (currentPanel?.dataset.acmView === state.view) {
        updatePanel(currentPanel);
        return;
      }

      currentPanel?.remove();
      hideSiteModeCards(hand);
      const panel = document.createElement("section");
      panel.className = "acm-panel acm-floating-panel";
      panel.dataset.acmView = state.view;
      panel.innerHTML = state.view === "rooms" ? roomsHtml() : menuHtml();
      bindPanel(panel);
      hand.append(panel);
    } finally {
      window.setTimeout(() => {
        suppressMutationRender = false;
      }, 0);
    }
  }

  function renderServerStatus(hand) {
    const status = hand.querySelector("[data-acm-server-status]");
    if (!status) return;
    status.dataset.acmStatus = state.serverStatus;
    status.textContent = state.serverStatusText;
    status.title = state.serverStatus === "version-mismatch" ? "설치 페이지 열기" : "";
  }

  function updatePanel(panel) {
    panel.querySelectorAll("[data-acm-busy]").forEach((button) => {
      button.disabled = state.busy || state.loadingRooms && button.dataset.acmAction === "refresh";
    });

    const errorSlot = panel.querySelector("[data-acm-error]");
    if (errorSlot) {
      errorSlot.hidden = !state.error;
      errorSlot.textContent = state.error;
    }

    const statusSlot = panel.querySelector("[data-acm-status]");
    if (statusSlot) {
      statusSlot.hidden = !state.busy;
      statusSlot.textContent = state.busy ? "처리 중입니다..." : "";
    }

    const countSlot = panel.querySelector("[data-acm-count]");
    if (countSlot) {
      countSlot.textContent = state.loadingRooms ? "불러오는 중" : `현재 ${state.rooms.length}개`;
    }

    const roomList = panel.querySelector("[data-acm-room-list]");
    if (roomList) {
      roomList.innerHTML = roomButtonsHtml();
    }

    const emptySlot = panel.querySelector("[data-acm-empty]");
    if (emptySlot) {
      emptySlot.hidden = state.loadingRooms || Boolean(state.rooms.length);
    }
  }

  function menuHtml() {
    return `
      <div class="acm-panel-head">
        <div>
          <h2 class="acm-panel-title">공개방 생성/입장</h2>
          <p class="acm-panel-copy">방 생성은 기존 온라인 방 만들기와 같은 동작을 사용합니다.</p>
        </div>
        <div class="acm-actions">
          <button type="button" class="acm-button" data-acm-action="back" data-acm-busy>뒤로가기</button>
          <button type="button" class="acm-button acm-button-primary" data-acm-action="create" data-acm-busy ${state.busy ? "disabled" : ""}>공개방 만들기</button>
          <button type="button" class="acm-button" data-acm-action="rooms" data-acm-busy ${state.busy ? "disabled" : ""}>공개방 입장</button>
        </div>
      </div>
      <p class="acm-error" data-acm-error ${state.error ? "" : "hidden"}>${escapeHtml(state.error)}</p>
      <p class="acm-status" data-acm-status ${state.busy ? "" : "hidden"}>${state.busy ? "처리 중입니다..." : ""}</p>
    `;
  }

  function roomsHtml() {
    const emptyHidden = state.loadingRooms || state.rooms.length ? "hidden" : "";
    return `
      <div class="acm-panel-head">
        <div>
          <h2 class="acm-panel-title">공개방 입장</h2>
          <p class="acm-panel-copy" data-acm-count>${state.loadingRooms ? "불러오는 중" : `현재 ${state.rooms.length}개`}</p>
        </div>
        <div class="acm-actions">
          <button type="button" class="acm-button" data-acm-action="menu">뒤로가기</button>
          <button type="button" class="acm-button" data-acm-action="refresh" data-acm-busy ${state.loadingRooms ? "disabled" : ""}>새로고침</button>
        </div>
      </div>
      <p class="acm-error" data-acm-error ${state.error ? "" : "hidden"}>${escapeHtml(state.error)}</p>
      <div class="acm-room-list" data-acm-room-list>${roomButtonsHtml()}</div>
      <p class="acm-empty" data-acm-empty ${emptyHidden}>현재 등록된 방이 없습니다.</p>
    `;
  }

  function roomButtonsHtml() {
    return state.rooms.map((room) => `
      <button type="button" class="acm-room-button" data-acm-room="${room.code}" ${state.busy ? "disabled" : ""}>
        <span class="acm-room-code">${room.code}</span>
        <span class="acm-room-meta">클릭해서 입장</span>
      </button>
    `).join("");
  }

  function bindPanel(panel) {
    panel.addEventListener("click", (event) => {
      const action = event.target.closest("[data-acm-action]")?.dataset.acmAction;
      if (action === "back") {
        closeEvents();
        state.view = "home";
        state.error = "";
        queueRender();
      } else if (action === "menu") {
        closeEvents();
        state.view = "menu";
        state.error = "";
        queueRender();
      } else if (action === "create") {
        void createRoom();
      } else if (action === "rooms") {
        state.view = "rooms";
        state.error = "";
        queueRender();
        void loadRooms();
        void connectEvents();
      } else if (action === "refresh") {
        void loadRooms();
      }

      const roomCode = event.target.closest("[data-acm-room]")?.dataset.acmRoom;
      if (roomCode) void joinRoom(roomCode);
    });
  }

  async function chooseOnlineMode() {
    const card = onlineModeCard();
    if (!card) throw new Error("온라인 모드 카드를 찾지 못했습니다.");
    card.click();
    await waitFor(() => {
      const button = document.querySelector("#onlineCreateButton");
      return isVisible(button) ? button : null;
    });
  }

  function visibleSiteButtonByText(pattern) {
    return [...document.querySelectorAll("button")].find((button) => {
      if (button.closest(".acm-panel, .acm-start-rejoin, .acm-chat-root")) return false;
      if (!isVisible(button)) return false;
      return pattern.test((button.textContent || "").replace(/\s+/g, " ").trim());
    });
  }

  async function returnToMainScreen() {
    closeEvents();
    state.view = "home";
    state.error = "";
    state.busy = false;
    state.createArmedUntil = 0;

    const overlay = document.querySelector("#modeOverlay");
    if (overlay?.hidden) {
      const modeSwitchButton = document.querySelector("#modeSwitchButton");
      if (isVisible(modeSwitchButton)) {
        modeSwitchButton.click();
      } else {
        visibleSiteButtonByText(/새\s*게임\s*모드\s*전환|모드\s*전환/)?.click();
      }
    }

    await waitFor(() => {
      const hand = modeHand();
      const currentOverlay = document.querySelector("#modeOverlay");
      return hand && !currentOverlay?.hidden ? hand : null;
    }, 2500).catch(() => null);
    if (!state.lastRoomCode) removeStartRejoinPrompt();
    queueRender();
  }

  async function createRoom() {
    try {
      state.busy = true;
      state.error = "";
      queueRender();
      state.createArmedUntil = Date.now() + 90000;
      await chooseOnlineMode();
      const button = await waitFor(() => {
        const candidate = document.querySelector("#onlineCreateButton");
        return isVisible(candidate) && !candidate.disabled ? candidate : null;
      });
      button.click();
      state.busy = false;
      queueRender();
    } catch (error) {
      state.error = error.message || String(error);
      state.busy = false;
      queueRender();
    }
  }

  async function joinRoom(code, options = {}) {
    try {
      state.busy = true;
      state.error = "";
      state.createArmedUntil = 0;
      if (options.forgetLastOnFailure) {
        state.rejoinAttemptCode = code;
        state.rejoinAttemptUntil = Date.now() + 10000;
      }
      queueRender();
      await removeRoom(code);
      await chooseOnlineMode();
      const input = await waitFor(() => document.querySelector("#roomCodeInput"));
      input.value = code;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      const button = await waitFor(() => {
        const candidate = document.querySelector("#onlineJoinButton");
        return isVisible(candidate) && !candidate.disabled ? candidate : null;
      });
      button.click();
      if (options.forgetLastOnFailure) {
        await waitForJoinResult(code, 5000);
      } else {
        await waitFor(() => onlineStatusRoomCode() === code ? code : null, 7000);
      }
      state.rejoinAttemptCode = "";
      state.rejoinAttemptUntil = 0;
      state.busy = false;
      queueRender();
    } catch (error) {
      if (options.forgetLastOnFailure) {
        await markRoomClosed(code);
        removeStartRejoinPrompt();
      }
      if (options.returnHomeOnFailure) {
        await returnToMainScreen();
      } else {
        state.error = error.message || String(error);
      }
      state.busy = false;
      queueRender();
    }
  }

  async function waitForJoinResult(code, timeoutMs) {
    const result = await waitFor(() => {
      if (onlineJoinFailureDetected()) return "failed";
      return onlineStatusRoomCode() === code ? "joined" : null;
    }, timeoutMs);
    if (result === "failed") throw new Error("존재하지 않거나 이미 다 채워진 방 코드입니다.");
    return result;
  }

  async function loadRooms() {
    state.loadingRooms = true;
    state.error = "";
    queueRender();
    try {
      const data = await apiFetch("/rooms");
      state.rooms = Array.isArray(data?.rooms) ? data.rooms : [];
    } catch (error) {
      state.error = `방 목록을 불러오지 못했습니다: ${error.message || error}`;
    } finally {
      state.loadingRooms = false;
      queueRender();
    }
  }

  function clearPublishedRoom(code = state.publishedCode) {
    if (!ROOM_CODE_RE.test(code) || state.publishedCode !== code) return;
    state.publishedCode = "";
    state.publishedHeartbeatAt = 0;
    state.publishedHeartbeatFailures = 0;
  }

  async function heartbeatPublishedRoom(code) {
    if (!ROOM_CODE_RE.test(code) || state.publishedCode !== code || heartbeatInFlight) return;
    heartbeatInFlight = true;
    try {
      await apiFetch(`/rooms/${code}/heartbeat`, { method: "POST", body: "{}" });
      state.publishedHeartbeatAt = Date.now();
      state.publishedHeartbeatFailures = 0;
    } catch (error) {
      state.publishedHeartbeatFailures += 1;
      console.warn("[Augment Matchmaking] heartbeat failed", error);
      if (state.publishedHeartbeatFailures >= 3) {
        clearPublishedRoom(code);
      }
    } finally {
      heartbeatInFlight = false;
    }
  }

  function closePublishedRoomByBeacon() {
    const code = state.publishedCode;
    if (!ROOM_CODE_RE.test(code)) return;
    const url = `${cachedServerBaseUrl}/rooms/${code}/close`;
    const body = new Blob(["{}"], { type: "application/json" });
    if (navigator.sendBeacon?.(url, body)) return;
    fetch(url, {
      method: "POST",
      body: "{}",
      headers: { "content-type": "application/json" },
      keepalive: true
    }).catch(() => {});
  }

  async function publishRoom(code) {
    if (!ROOM_CODE_RE.test(code) || state.publishedCode === code) return;
    try {
      await apiFetch("/rooms", {
        method: "POST",
        body: JSON.stringify({ code, source: "augmentchess-extension" })
      });
      state.publishedCode = code;
      state.publishedHeartbeatAt = 0;
      state.publishedHeartbeatFailures = 0;
      state.createArmedUntil = 0;
      void heartbeatPublishedRoom(code);
    } catch (error) {
      console.warn("[Augment Matchmaking] publish failed", error);
    } finally {
      state.busy = false;
    }
  }

  async function removeRoom(code) {
    if (!ROOM_CODE_RE.test(code)) return;
    clearPublishedRoom(code);
    state.rooms = state.rooms.filter((room) => room.code !== code);
    queueRender();
    try {
      await apiFetch(`/rooms/${code}/claim`, { method: "POST", body: "{}" });
    } catch (error) {
      console.warn("[Augment Matchmaking] remove failed", error);
    }
  }

  async function connectEvents() {
    closeEvents();
    try {
      const baseUrl = await serverBaseUrl();
      const events = new EventSource(`${baseUrl}/events`);
      state.eventSource = events;
      events.addEventListener("snapshot", (event) => applyRooms(JSON.parse(event.data).rooms));
      events.addEventListener("room-created", (event) => {
        const room = JSON.parse(event.data);
        applyRooms([room, ...state.rooms]);
      });
      events.addEventListener("room-removed", (event) => {
        const room = JSON.parse(event.data);
        state.rooms = state.rooms.filter((candidate) => candidate.code !== room.code);
        queueRender();
      });
      events.onerror = () => {
        state.error = "실시간 연결이 끊겼습니다. 새로고침을 눌러 다시 확인하세요.";
        queueRender();
      };
    } catch (error) {
      state.error = `실시간 연결 실패: ${error.message || error}`;
      queueRender();
    }
  }

  function closeEvents() {
    state.eventSource?.close();
    state.eventSource = null;
  }

  async function startChatForRoom(code) {
    if (!ROOM_CODE_RE.test(code) || chatState.roomCode === code) return;
    stopChat();
    chatState.roomCode = code;
    chatState.status = "상대 연결 대기 중";
    chatState.missingRoomChecks = 0;
    chatState.panelOpen = false;
    ensureChatUi();
    renderChat();

    if (!globalThis.RTCPeerConnection) {
      chatState.status = "이 브라우저에서 P2P 채팅을 사용할 수 없습니다.";
      renderChat();
      return;
    }

    try {
      const baseUrl = await serverBaseUrl();
      const source = new EventSource(`${baseUrl}/rooms/${code}/signals/events?peerId=${encodeURIComponent(chatState.peerId)}`);
      let announced = false;
      chatState.signalSource = source;
      const announce = () => {
        if (announced || chatState.roomCode !== code) return;
        announced = true;
        void sendChatSignal("hello", { peerId: chatState.peerId });
      };
      source.addEventListener("open", announce);
      source.addEventListener("signal-ready", announce);
      source.addEventListener("signal", (event) => {
        void handleChatSignal(JSON.parse(event.data));
      });
      source.onerror = () => {
        if (chatState.roomCode !== code) return;
        chatState.status = "채팅 연결 신호 대기 중";
        renderChat();
      };
    } catch (error) {
      chatState.status = `채팅 연결 실패: ${error.message || error}`;
      renderChat();
    }
  }

  function stopChat() {
    chatState.signalSource?.close();
    chatState.signalSource = null;
    for (const peer of chatState.peers.values()) {
      peer.channel?.close();
      peer.pc.close();
    }
    chatState.peers.clear();
    chatState.roomCode = "";
    chatState.messages = [];
    chatState.seenMessages.clear();
    chatState.missingRoomChecks = 0;
    chatState.status = "";
    chatState.unread = 0;
    renderChat();
  }

  async function sendChatSignal(type, data = null, to = "") {
    if (!chatState.roomCode) return;
    try {
      await apiFetch(`/rooms/${chatState.roomCode}/signals`, {
        method: "POST",
        body: JSON.stringify({
          from: chatState.peerId,
          to,
          type,
          data
        })
      });
    } catch (error) {
      console.warn("[Augment Matchmaking] chat signal failed", error);
      chatState.status = "채팅 연결 서버에 닿지 않습니다.";
      renderChat();
    }
  }

  async function handleChatSignal(message) {
    if (!message || message.from === chatState.peerId) return;
    if (message.code !== chatState.roomCode) return;
    if (message.to && message.to !== chatState.peerId) return;

    if (message.type === "hello") {
      if (shouldInitiateChat(message.from)) {
        createChatPeer(message.from, true);
      } else {
        await sendChatSignal("hello-ack", null, message.from);
      }
      return;
    }

    if (message.type === "hello-ack") {
      if (shouldInitiateChat(message.from)) createChatPeer(message.from, true);
      return;
    }

    if (message.type === "offer") {
      await acceptChatOffer(message.from, message.data);
      return;
    }

    if (message.type === "answer") {
      await acceptChatAnswer(message.from, message.data);
      return;
    }

    if (message.type === "ice") {
      await addChatIceCandidate(message.from, message.data);
    }
  }

  function shouldInitiateChat(remotePeerId) {
    return chatState.peerId.localeCompare(remotePeerId) < 0;
  }

  function createChatPeer(remotePeerId, initiator) {
    const existing = chatState.peers.get(remotePeerId);
    if (existing) return existing;

    const pc = new RTCPeerConnection({
      iceServers: [{ urls: "stun:stun.l.google.com:19302" }]
    });
    const peer = {
      id: remotePeerId,
      pc,
      channel: null,
      pendingCandidates: []
    };
    chatState.peers.set(remotePeerId, peer);

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        void sendChatSignal("ice", event.candidate.toJSON(), remotePeerId);
      }
    };
    pc.ondatachannel = (event) => setupChatChannel(peer, event.channel);
    pc.onconnectionstatechange = () => {
      if (["failed", "closed", "disconnected"].includes(pc.connectionState)) {
        chatState.status = "상대 연결이 끊겼습니다.";
      }
      renderChat();
    };

    if (initiator) {
      setupChatChannel(peer, pc.createDataChannel("augment-chat"));
      void createChatOffer(peer);
    }

    renderChat();
    return peer;
  }

  async function createChatOffer(peer) {
    try {
      const offer = await peer.pc.createOffer();
      await peer.pc.setLocalDescription(offer);
      await sendChatSignal("offer", sessionDescriptionPayload(peer.pc.localDescription), peer.id);
    } catch (error) {
      console.warn("[Augment Matchmaking] chat offer failed", error);
      chatState.status = "채팅 제안을 만들지 못했습니다.";
      renderChat();
    }
  }

  async function acceptChatOffer(remotePeerId, offer) {
    const peer = createChatPeer(remotePeerId, false);
    try {
      await peer.pc.setRemoteDescription(new RTCSessionDescription(offer));
      await flushChatIceCandidates(peer);
      const answer = await peer.pc.createAnswer();
      await peer.pc.setLocalDescription(answer);
      await sendChatSignal("answer", sessionDescriptionPayload(peer.pc.localDescription), remotePeerId);
    } catch (error) {
      console.warn("[Augment Matchmaking] chat offer accept failed", error);
      chatState.status = "채팅 제안을 처리하지 못했습니다.";
      renderChat();
    }
  }

  async function acceptChatAnswer(remotePeerId, answer) {
    const peer = createChatPeer(remotePeerId, false);
    try {
      await peer.pc.setRemoteDescription(new RTCSessionDescription(answer));
      await flushChatIceCandidates(peer);
    } catch (error) {
      console.warn("[Augment Matchmaking] chat answer failed", error);
      chatState.status = "채팅 응답을 처리하지 못했습니다.";
      renderChat();
    }
  }

  async function addChatIceCandidate(remotePeerId, candidateData) {
    if (!candidateData) return;
    const peer = createChatPeer(remotePeerId, false);
    const candidate = new RTCIceCandidate(candidateData);
    if (!peer.pc.remoteDescription) {
      peer.pendingCandidates.push(candidate);
      return;
    }
    try {
      await peer.pc.addIceCandidate(candidate);
    } catch (error) {
      console.warn("[Augment Matchmaking] chat ICE failed", error);
    }
  }

  function sessionDescriptionPayload(description) {
    return {
      type: description.type,
      sdp: description.sdp
    };
  }

  async function flushChatIceCandidates(peer) {
    while (peer.pendingCandidates.length) {
      const candidate = peer.pendingCandidates.shift();
      await peer.pc.addIceCandidate(candidate).catch((error) => {
        console.warn("[Augment Matchmaking] queued chat ICE failed", error);
      });
    }
  }

  function setupChatChannel(peer, channel) {
    peer.channel = channel;
    channel.onopen = () => {
      chatState.status = "상대와 직접 연결됨";
      renderChat();
    };
    channel.onclose = () => {
      chatState.status = "상대 연결이 끊겼습니다.";
      renderChat();
    };
    channel.onerror = () => {
      chatState.status = "채팅 채널 오류";
      renderChat();
    };
    channel.onmessage = (event) => {
      handleChatData(peer.id, event.data);
    };
  }

  function handleChatData(remotePeerId, raw) {
    let payload;
    try {
      payload = JSON.parse(String(raw));
    } catch {
      return;
    }
    if (payload?.type !== "chat" || !payload.text) return;
    const id = String(payload.id || `${remotePeerId}-${payload.at || Date.now()}`);
    if (chatState.seenMessages.has(id)) return;
    chatState.seenMessages.add(id);
    addChatMessage({
      id,
      own: false,
      author: "상대",
      text: String(payload.text).slice(0, 240),
      at: Number(payload.at) || Date.now()
    });
  }

  function sendChatMessage(text) {
    const trimmed = String(text || "").trim();
    if (!trimmed) return;
    const channels = openChatChannels();
    if (!channels.length) {
      chatState.status = "상대 연결 대기 중";
      renderChat();
      return;
    }
    const message = {
      id: `${chatState.peerId}-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      type: "chat",
      from: chatState.peerId,
      text: trimmed.slice(0, 240),
      at: Date.now()
    };
    chatState.seenMessages.add(message.id);
    for (const channel of channels) {
      channel.send(JSON.stringify(message));
    }
    addChatMessage({
      id: message.id,
      own: true,
      author: "나",
      text: message.text,
      at: message.at
    });
  }

  function addChatMessage(message) {
    chatState.messages.push(message);
    if (chatState.messages.length > 100) {
      const removed = chatState.messages.splice(0, chatState.messages.length - 100);
      removed.forEach((item) => chatState.seenMessages.delete(item.id));
    }
    if (!message.own && !chatState.panelOpen) chatState.unread += 1;
    renderChat();
  }

  function openChatChannels() {
    return [...chatState.peers.values()]
      .map((peer) => peer.channel)
      .filter((channel) => channel?.readyState === "open");
  }

  function ensureChatUi() {
    if (chatState.root) return chatState.root;
    const root = document.createElement("aside");
    root.className = "acm-chat-root";
    root.hidden = true;
    root.innerHTML = `
      <button type="button" class="acm-chat-toggle" data-acm-chat-toggle>
        <span>채팅</span>
        <strong data-acm-chat-unread hidden></strong>
      </button>
      <section class="acm-chat-panel" data-acm-chat-panel hidden>
        <header class="acm-chat-head">
          <div>
            <h2>공개방 채팅</h2>
            <p data-acm-chat-status></p>
          </div>
          <button type="button" class="acm-chat-close" data-acm-chat-close aria-label="채팅 닫기">×</button>
        </header>
        <div class="acm-chat-messages" data-acm-chat-messages></div>
        <form class="acm-chat-form" data-acm-chat-form>
          <input type="text" data-acm-chat-input maxlength="240" autocomplete="off" placeholder="메시지 입력" />
          <button type="submit" data-acm-chat-send>전송</button>
        </form>
      </section>
    `;
    root.addEventListener("click", (event) => {
      if (event.target.closest("[data-acm-chat-toggle]")) {
        chatState.panelOpen = !chatState.panelOpen;
        if (chatState.panelOpen) chatState.unread = 0;
        renderChat();
      }
      if (event.target.closest("[data-acm-chat-close]")) {
        chatState.panelOpen = false;
        renderChat();
      }
    });
    root.querySelector("[data-acm-chat-form]").addEventListener("submit", (event) => {
      event.preventDefault();
      const input = root.querySelector("[data-acm-chat-input]");
      sendChatMessage(input.value);
      input.value = "";
      input.focus();
    });
    document.body.append(root);
    chatState.root = root;
    return root;
  }

  function renderChat() {
    const root = chatState.root || ensureChatUi();
    const visible = Boolean(chatState.roomCode);
    root.hidden = !visible;
    if (!visible) return;

    const panel = root.querySelector("[data-acm-chat-panel]");
    panel.hidden = !chatState.panelOpen;
    root.classList.toggle("acm-chat-open", chatState.panelOpen);

    const unread = root.querySelector("[data-acm-chat-unread]");
    unread.hidden = chatState.unread < 1;
    unread.textContent = String(chatState.unread);

    const connectedCount = openChatChannels().length;
    const status = root.querySelector("[data-acm-chat-status]");
    status.textContent = `${chatState.roomCode} · ${connectedCount ? `${connectedCount}명 연결됨` : chatState.status || "상대 연결 대기 중"}`;

    const messages = root.querySelector("[data-acm-chat-messages]");
    messages.innerHTML = chatState.messages.length
      ? chatState.messages.map(chatMessageHtml).join("")
      : `<p class="acm-chat-empty">상대가 접속하면 바로 채팅할 수 있습니다.</p>`;
    messages.scrollTop = messages.scrollHeight;

    const input = root.querySelector("[data-acm-chat-input]");
    const send = root.querySelector("[data-acm-chat-send]");
    const enabled = connectedCount > 0;
    input.disabled = !enabled;
    send.disabled = !enabled;
  }

  function chatMessageHtml(message) {
    return `
      <div class="acm-chat-message ${message.own ? "acm-chat-message-own" : ""}">
        <span class="acm-chat-author">${escapeHtml(message.author)}</span>
        <p>${escapeHtml(message.text)}</p>
      </div>
    `;
  }

  function applyRooms(rooms) {
    const byCode = new Map();
    [...(rooms || []), ...state.rooms].forEach((room) => {
      if (room?.code) byCode.set(room.code, room);
    });
    state.rooms = [...byCode.values()].sort((a, b) => {
      return String(b.createdAt || "").localeCompare(String(a.createdAt || ""));
    });
    queueRender();
  }

  function detectRoomCode() {
    const statusText = document.querySelector("#onlineStatus")?.textContent || "";
    const inputValue = document.querySelector("#roomCodeInput")?.value || "";
    return statusText.match(ROOM_CODE_RE)?.[0] || inputValue.match(ROOM_CODE_RE)?.[0] || "";
  }

  function onlineStatusRoomCode() {
    const status = document.querySelector("#onlineStatus");
    if (!isVisible(status)) return "";
    return (status.textContent || "").match(ROOM_CODE_RE)?.[0] || "";
  }

  function onlineClosedRoomDetected() {
    const status = document.querySelector("#onlineStatus");
    const players = document.querySelector("#onlinePlayersStatus");
    const statusText = isVisible(status) ? status.textContent || "" : "";
    const playersText = isVisible(players) ? players.textContent || "" : "";
    return /삭제|닫힘|닫혔|종료|존재하지|만료/.test(`${statusText} ${playersText}`);
  }

  function onlineJoinFailureDetected() {
    const toast = document.querySelector("#toast");
    const statusTitle = document.querySelector("#statusTitle");
    const statusText = document.querySelector("#statusText");
    const text = [
      toast?.textContent || "",
      statusTitle?.textContent || "",
      statusText?.textContent || "",
      document.querySelector("#onlineStatus")?.textContent || ""
    ].join(" ");
    return /존재하지 않거나 이미 다 채워진 방 코드|방 입장 실패|방 코드를 입력하세요/.test(text);
  }

  function watchOnlineState() {
    const code = detectRoomCode();
    if (code && Date.now() < state.createArmedUntil) {
      void publishRoom(code);
    }

    if (state.publishedCode && Date.now() - state.publishedHeartbeatAt >= ROOM_HEARTBEAT_MS) {
      void heartbeatPublishedRoom(state.publishedCode);
    }

    if (state.rejoinAttemptCode && Date.now() < state.rejoinAttemptUntil && onlineJoinFailureDetected()) {
      const failedCode = state.rejoinAttemptCode;
      state.rejoinAttemptCode = "";
      state.rejoinAttemptUntil = 0;
      void markRoomClosed(failedCode);
      removeStartRejoinPrompt();
      stopChat();
      void returnToMainScreen();
      return;
    }

    const activeRoomCode = onlineStatusRoomCode();
    if (onlineClosedRoomDetected()) {
      const closedCode = activeRoomCode || code || chatState.roomCode || state.lastRoomCode || state.publishedCode;
      void markRoomClosed(closedCode);
      if (state.publishedCode) void removeRoom(state.publishedCode);
      stopChat();
      return;
    }

    if (activeRoomCode) {
      chatState.missingRoomChecks = 0;
      if (isClosedRoomCode(activeRoomCode)) {
        void forgetLastRoomCode();
        stopChat();
      } else {
        void rememberLastRoomCode(activeRoomCode);
        void startChatForRoom(activeRoomCode);
      }
    } else if (chatState.roomCode) {
      const choosingMode = !document.querySelector("#modeOverlay")?.hidden;
      chatState.missingRoomChecks += 1;
      if (choosingMode || chatState.missingRoomChecks >= 3) {
        stopChat();
      }
    }

    const playersText = document.querySelector("#onlinePlayersStatus")?.textContent || "";
    if (state.publishedCode && playersText && !playersText.includes("\uBE48\uC790\uB9AC")) {
      const codeToRemove = state.publishedCode;
      void removeRoom(codeToRemove);
    }
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (char) => {
      return {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
      }[char];
    });
  }

  document.addEventListener("click", (event) => {
    if (event.target.closest("#onlineCreateButton")) {
      state.createArmedUntil = Date.now() + 90000;
    }
    if (event.target.closest("#onlineDeleteButton")) {
      const closedCode = onlineStatusRoomCode() || detectRoomCode() || chatState.roomCode || state.lastRoomCode || state.publishedCode;
      void markRoomClosed(closedCode);
    }
    if (event.target.closest("#onlineDeleteButton, #onlineLeaveButton")) {
      if (state.publishedCode) void removeRoom(state.publishedCode);
      stopChat();
    }
  }, true);

  const overlayObserver = new MutationObserver(() => {
    if (suppressMutationRender) return;
    if (document.querySelector("#modeOverlay")?.hidden && state.view !== "home") {
      closeEvents();
      state.view = "home";
    }
    queueRender();
  });

  const handObserver = new MutationObserver(() => {
    if (suppressMutationRender) return;
    const hand = modeHand();
    if (!hand) return;
    const needsHomeCard = state.view === "home" && !hand.querySelector('[data-card-id="mode-matchmaking"]');
    const needsStartRejoin = state.view === "home" && state.lastRoomCode && !hand.querySelector(".acm-start-rejoin");
    const needsPanel = state.view !== "home" && !hand.querySelector(".acm-panel");
    if (needsHomeCard || needsStartRejoin || needsPanel) queueRender();
  });

  const bootstrapObserver = new MutationObserver(() => installTargetObservers());

  function installTargetObservers() {
    const overlay = document.querySelector("#modeOverlay");
    const hand = modeHand();
    let changed = false;

    if (overlay && overlay !== observedOverlay) {
      overlayObserver.disconnect();
      overlayObserver.observe(overlay, { attributes: true, attributeFilter: ["hidden"] });
      observedOverlay = overlay;
      changed = true;
    }

    if (hand && hand !== observedHand) {
      handObserver.disconnect();
      handObserver.observe(hand, { childList: true });
      observedHand = hand;
      changed = true;
    }

    if (overlay && hand) {
      bootstrapObserver.disconnect();
    }

    if (changed) queueRender();
  }

  bootstrapObserver.observe(document.body || document.documentElement, {
    childList: true,
    subtree: true
  });

  installTargetObservers();
  void loadLastRoomCode();
  void checkServerStatus();
  window.addEventListener("pagehide", closePublishedRoomByBeacon);
  window.addEventListener("beforeunload", closePublishedRoomByBeacon);
  window.setInterval(watchOnlineState, 1000);
  window.setInterval(checkServerStatus, SERVER_STATUS_CHECK_MS);
})();
