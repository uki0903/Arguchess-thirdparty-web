const DEFAULT_SERVER_URL = "https://port-0-arguchessthird-mqufv2f3f11bcb06.sel3.cloudtype.app";
const LEGACY_DEFAULT_SERVER_URLS = new Set(["http://localhost:8787", "http://localhost:3000"]);
const input = document.querySelector("#serverUrl");
const statusText = document.querySelector("#status");

function normalizeServerUrl(value) {
  const normalized = String(value || "").trim().replace(/\/+$/, "");
  if (!normalized || LEGACY_DEFAULT_SERVER_URLS.has(normalized)) return DEFAULT_SERVER_URL;
  return normalized;
}

chrome.storage.sync.get({ serverUrl: "" }, (items) => {
  const savedServerUrl = String(items.serverUrl || "").trim().replace(/\/+$/, "");
  const serverUrl = normalizeServerUrl(savedServerUrl);
  input.value = serverUrl;
  if (serverUrl !== savedServerUrl) {
    chrome.storage.sync.set({ serverUrl });
  }
});

document.querySelector("#save").addEventListener("click", () => {
  const serverUrl = normalizeServerUrl(input.value);
  chrome.storage.sync.set({ serverUrl }, () => {
    statusText.textContent = "저장했습니다. 열려 있는 증강 체스 탭을 새로고침하세요.";
  });
});
